import request from '@/utils/http/axios/index'
import { AxiosResponse } from 'axios'

/**
 * 分类相关API
 * 校园二手交易平台
 */

// 分类信息
interface Category {
  id: number
  name: string
  icon: string
  description: string
  createTime: string
  productCount?: number
}

/**
 * 获取分类列表
 */
export const getCategoryList = (): Promise<AxiosResponse> => {
  return request({
    url: '/index/category/list',
    method: 'get'
  })
}

/**
 * 获取分类详情
 */
export const getCategoryDetail = (id: number): Promise<AxiosResponse> => {
  return request({
    url: '/index/category/detail',
    method: 'get',
    params: { id }
  })
}

/**
 * 获取分类及商品数量
 */
export const getCategoryListWithProducts = (): Promise<AxiosResponse> => {
  return request({
    url: '/index/category/listWithProducts',
    method: 'get'
  })
}