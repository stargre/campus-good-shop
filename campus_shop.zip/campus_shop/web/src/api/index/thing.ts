// 权限问题后期增加
import { get, post } from '/@/utils/http/axios';
import { UserState } from '/@/store/modules/user/types';
// import axios from 'axios';
enum URL {
    list = '/myapp/index/product/list',
    detail = '/myapp/index/product/detail',
    addWishUser = '/myapp/index/product/addWishUser',
    addCollectUser = '/myapp/index/product/addCollectUser',
    getCollectThingList = '/myapp/index/product/getCollectThingList',
    getWishThingList = '/myapp/index/product/getWishThingList',
    removeCollectUser = '/myapp/index/product/removeCollectUser',
    removeWishUser = '/myapp/index/product/removeWishUser'
}

const productListApi = async (params: any) => get<any>({ url: URL.list, params: params, data: {}, headers: {} });
const productDetailApi = async (params: any) => get<any>({ url: URL.detail, params: params, headers: {} });
const addProductWishUserApi = async (params: any) => post<any>({ url: URL.addWishUser, params: params, headers: {} });
const addProductCollectUserApi = async (params: any) => post<any>({ url: URL.addCollectUser, params: params, headers: {} });
const getProductCollectListApi = async (params: any) => get<any>({ url: URL.getCollectThingList, params: params, headers: {} });
const getProductWishListApi = async (params: any) => get<any>({ url: URL.getWishThingList, params: params, headers: {} });

const removeProductCollectUserApi = async (params: any) => post<any>({ url: URL.removeCollectUser, params: params, headers: {} });
const removeProductWishUserApi = async (params: any) => post<any>({ url: URL.removeWishUser, params: params, headers: {} });

// 保留原有API名称作为别名以兼容现有代码
const listApi = productListApi;
const detailApi = productDetailApi;
const addWishUserApi = addProductWishUserApi;
const addCollectUserApi = addProductCollectUserApi;
const getCollectThingListApi = getProductCollectListApi;
const getWishThingListApi = getProductWishListApi;
const removeCollectUserApi = removeProductCollectUserApi;
const removeWishUserApi = removeProductWishUserApi;


export { 
    // 新API名称
    productListApi, productDetailApi, addProductWishUserApi, addProductCollectUserApi, 
    getProductCollectListApi, getProductWishListApi, removeProductCollectUserApi, removeProductWishUserApi,
    // 原有API名称作为别名以兼容现有代码
    listApi, detailApi, addWishUserApi, addCollectUserApi, getCollectThingListApi,
    getWishThingListApi, removeCollectUserApi, removeWishUserApi 
};
