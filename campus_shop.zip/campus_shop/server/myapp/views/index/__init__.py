from myapp.views.index.classification import *
from myapp.views.index.category import *
from myapp.views.index.user import *
from myapp.views.index.comment import *
from myapp.views.index.order import *
from myapp.views.index.notice import *
from myapp.views.index.address import *
from myapp.views.index.product import *